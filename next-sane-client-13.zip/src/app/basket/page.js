'use client'
import React from 'react'
import BasketDetail from '@/components/templates/Basket/BasketDetail'

export default function basket() {
 
  return (

<BasketDetail/>


  )
}
