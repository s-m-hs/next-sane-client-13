import Layout from '@/components/layouts/UserPanelLayout'
import TabCom from '@/components/madules/p-user/TabCom';
import React from 'react'
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';

export default function Ticket() {
  return (
<div>Ticket</div>
  )
}
