import ProfileCom from '@/components/madules/p-user/Profile/ProfileCom'
import React from 'react'

export default function Profile() {
  return (
  <ProfileCom/>
  )
}
