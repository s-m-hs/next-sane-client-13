import React from "react";
import Sidebar from "@/components/madules/p-user/Sidebar";
import Layout from "@/components/layouts/UserPanelLayout";

function Index() {
  return (
<div></div>
  );
}

export default Index;
