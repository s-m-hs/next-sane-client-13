import React from 'react'
import RegisterTemplate from '@/components/templates/Register/RegisterTemplate'
export default function Register() {
  return (
    <div className='container ' style={{height:'600px', marginTop:'100px'}}>
   <RegisterTemplate/>
      
    </div>
  )
}
