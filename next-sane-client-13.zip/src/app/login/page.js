import React from 'react'
import LoginTemplate from '@/components/templates/Login/LoginTemplate'

export default function LoginPage
() {
  return (
    <div className='container ' style={{height:'600px', marginTop:'100px'}}>
    <LoginTemplate/>
       
     </div>
  )
}
