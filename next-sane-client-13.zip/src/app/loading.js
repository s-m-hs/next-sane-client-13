'use client'
import React from 'react'
import SpinnerA from '@/utils/SpinnerA/SpinnerA'

export default function Loading() {
  return (
    <div className='centerr'>
        <SpinnerA/>
    </div>

  
  )
}
