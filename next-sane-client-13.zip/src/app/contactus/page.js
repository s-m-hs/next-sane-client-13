import React from 'react'
import Contact from '@/components/templates/Contact/Contact'

export default function ContactUs() {
  return (
    <Contact/>
  )
}
