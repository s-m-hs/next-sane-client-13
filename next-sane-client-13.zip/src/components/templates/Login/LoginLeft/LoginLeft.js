import React from 'react'
import style from './LoginLeft.module.css'
export default function LoginLeft() {
  return (
    <div className={style.div}>
      {/* <img className={style.img} src="../../../../../images/register/login-570317_1280.jpg" alt="" /> */}
      {/* <img className={style.img} src="../../../../../images/register/password-7476798_1280.png" alt="" /> */}
      {/* <img className={style.img} src="../../../../../images/register/user-privacy-control-icon-design-vector.jpg" alt="" /> */}
      {/* <img className={style.img} src="../../../../../images/register/11168381.png" alt="" /> */}
      {/* <img className={style.img} src="../../../../../images/register/3301491_490541-PHC6ZR-437.jpg" alt="" /> */}
      {/* <img className={style.img} src="../../../../../images/register/11667128_20943446.jpg" alt="" /> */}
      {/* <img className={style.img} src="../../../../../images/register/11667132_20943447.jpg" alt="" /> */}
      <img className={style.img} src="../../../../../images/register/photo_2024-08-05_16-37-06.jpg" alt="" />
      {/* <img className={style.img} src="../../../../../images/register/3316536_491859-PHBH2C-303.jpg" alt="" /> */}
      {/* <img className={style.img} src="../../../../../images/register/3410197_495622-PI4N2F-700.jpg" alt="" /> */}
    </div>
  )
}
