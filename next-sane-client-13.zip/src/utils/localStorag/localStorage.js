
const getLocalStorage=localStorage.getItem('loginToken')



export default getLocalStorage