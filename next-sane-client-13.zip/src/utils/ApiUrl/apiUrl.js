const apiUrl=`http://sapi.sanecomputer.com`



export default apiUrl